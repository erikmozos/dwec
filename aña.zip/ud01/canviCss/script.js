const titol = document.getElementById("titol");

function canviarEstil() {
    titol.style.fontSize = "30px";  
    titol.style.color = "blue";
}