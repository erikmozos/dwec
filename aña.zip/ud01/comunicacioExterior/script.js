const tester = document.getElementById('tester');

tester.innerHTML = 5 + 6;

document.write('<p>boqueron</p>')