function suma(a, b){
    let s = a + b;
    console.log(s);
}