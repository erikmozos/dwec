//Numeros 
let a = 400;
let b = 9.85;
let c = 3.1456e9;
const pi = 3.1415529;

//Aritmetica
console.log(9/(3+4-2)*3);


//Numeros especiales
//Infinity i -Infinity
console.log(Infinity - Infinity);
console.log(NaN);

//Cadenes (String)

console.log('hola');
console.log("aña");
console.log(`huh`);

//Salt de linia
console.log('Salt \nde\n\'linia\'');
let cadena = "nar";
console.log("con" + "cate" + cadena);

//Template literals
console.log("La meitat de 100 és " + 100/2);
console.log(`La meitat de 100 és ${100/2}`);

//Operados unaris
console.log(typeof 'x');

//Binaris
console.log(7-5);
console.log(-6);

//Boolean
console.log(3<2);
console.log(3>2);
console.log("Axor" < "ñ");

//Operadores logicos
console.log(true && false);

//Operador terniari
console.log(true ? 1:2);
console.log(false ? 1:2);

//Valors buits
// null i undefined

// && ||
