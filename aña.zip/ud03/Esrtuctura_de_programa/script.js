// let numero = "2";
// let calculo = 3 * 8;
// let compuesta = 5 * (numero + calculo);
// console.log(compuesta);

// {

//     let pepe = "pepe";
//     // console.log(pepe);

// }

while(true){
    let usuario = prompt("Ingrese nombre de usuario")
    if(usuario != ""){
        break;
    }
    }

console.log(Math.max(20, 200));