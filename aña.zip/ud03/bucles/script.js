// // // let numero = 2;
// // // let limite = 200;
// // // let suma = 0;
// // // while(numero <= limite){
// // //     console.log(numero);
// // //     suma = numero + suma;
// // //     numero = numero + 2;
// // // }

// // // // console.log(suma);

// // let numero = prompt("Introduce el número:");
// // while (isNaN(numero)) {
// //     numero = prompt("Eso no es un número válido. Introduce el número nuevamente:");
// // }

// // let potencia = prompt("Introduce la potencia:");
// // while (isNaN(potencia) || potencia % 1 !== 0) { // Verificar si es un número entero
// //     potencia = prompt("Eso no es un número entero válido. Introduce la potencia nuevamente:");
// // }
// // numero = Number(numero);
// // potencia = Number(potencia);
// // let resultado = 1;
// // for (let i = 0; i < potencia; i++) {
// //     resultado *= numero;
// // }
// // console.log(`El resultado de ${numero} elevado a la potencia ${potencia} es: ${resultado}`);

// //Bucle FOR
// for (let numero=0; numero <= 12; numero += 2){
//     console.log(numero);
// }

// for(let numero = 20; numero < 100; numero++){
//     if(numero % 7 == 0 ){
//         console.log(numero);
//     }
// }

// for(let numero = 20; numero < 100; numero++){
//     if(numero % 7 != 0 ){
//         continue;
//     }
//     console.log(numero);
// }