// Capture the elements from the DOM
const form = document.getElementById('form');
const userName = document.getElementById('userName');
const email = document.getElementById('email');
const password = document.getElementById('password');
const passwordConfirm = document.getElementById('passwordConfirm');

// Functions

function showError(input, message) {
    const formControl = input.parentElement;
    formControl.className = 'form-control error';
    const label = formControl.querySelector('label');
    const small = formControl.querySelector('small');
    small.innerText = label.innerText + " " + message;
}

function showCorrect(input) {
    const formControl = input.parentElement;
    formControl.className = 'form-control correct';
}

// Events


// userName.addEventListener('blur', () => {
//     if (!(userName.value === '')) {
//         showCorrect(userName);
//     }else{
//         showError(userName,'is required');
//     }
// });

form.addEventListener('submit', (e) => {
    
    e.preventDefault();

    if (userName.value === '') {
        showError(userName,'is required');
    }else{
        showCorrect(userName);
    }

    if (email.value === '') {
        showError(email,'is required');
    }else{
        showCorrect(email);
    }

    if (password.value === '') {
        showError(password,'is required');
    }
    else{
        showCorrect(password);
    }

    if (passwordConfirm.value === '') {
        showError(passwordConfirm,'is required');
    }else if(password.value !== passwordConfirm.value){
        showError(passwordConfirm,'is not equal');
    }else
    {
        showCorrect(passwordConfirm);
    }


});